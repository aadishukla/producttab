<?php

public function Ab(){
echo "ab here";
echo "ab executed";
}
