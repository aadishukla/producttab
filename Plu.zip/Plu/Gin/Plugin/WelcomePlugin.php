<?php
 
namespace Plu\Gin\Plugin;
 
 
class WelcomePlugin{
     
    
  public function afterAb()
    {
      echo'<script type="text/javascript"> alert("HDJrigf"); </script>';
    }

}
?>
