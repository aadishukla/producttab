<?php

namespace Name\Event\Observer;

use Magento\Framework\Event\ObserverInterface;

class Data implements ObserverInterface
{
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
         $customer = $observer->getEvent()->getCustomer();
 		 echo "<pre>";
	     print_r($customer->getData());

         echo $customer->getName(); //Get customer name
            
		// $displayText = $observer->getData('mp_text');
	 //    echo $displayText->getText() . " - Event </br>";
	 //    echo '<script type="text/javascript"> confirm("hii"); </script>';
	 //    $displayText->setText('Execute event successfully.');
	    
    }
}
?>
