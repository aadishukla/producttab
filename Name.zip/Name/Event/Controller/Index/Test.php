<?php
/*
Author;_-Adarsh Shukla
About Module:-This Module Is Aboue How To Carete A module Event.
it Also Have Ovserver FOr login And Resister

*/


namespace Name\Event\Controller\Index;
 
use Magento\Framework\App\Action\Context;
 
class Test extends \Magento\Framework\App\Action\Action
{
    protected $_resultPageFactory;
 
    public function __construct(Context $context, \Magento\Framework\View\Result\PageFactory $resultPageFactory)
    {
        $this->_resultPageFactory = $resultPageFactory;
        parent::__construct($context);
        
    }
 
    public function execute()
    { 
        $resultPage = $this->_resultPageFactory->create();
        $textDisplay = new \Magento\Framework\DataObject(array('text' => 'Mageplaza'));
        $this->_eventManager->dispatch('customer_login_custom', ['mp_text' => $textDisplay]);
        echo $textDisplay->getText();
  
        return $resultPage;

    }
}