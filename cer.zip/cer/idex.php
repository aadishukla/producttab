<!DOCTYPE html>
<html lang="en">
<head>
        <title>Untitled Document</title>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
        <script type="text/javascript" src="jseditor/editor.js"></script>
    </head>
    <body>
       <h1>Mail Sending page</h1>
        <form action="op.php" method="post">
            TO:-<input type="text" name="to" />
            Subject:- <input type="text" name="sub" />
              <p>
                <script>Start('tbox',800,400);   </script>
              </p>
              <p>
                <input type="submit" name="Submit" value="Submit"/>
              </p>
        </form>
    </body>
</html>