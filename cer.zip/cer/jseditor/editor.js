var myeditor; 
document.write("<link href=\"styles.css\" rel=\"stylesheet\" type=\"text/css\">");
window.onload = function() 
{ 
 myeditor = document.getElementById('rte').contentWindow.document; 
 myeditor.designMode = "on";
 
}


function doCheck(obj) {

document.getElementById(obj).value = myeditor.body.innerHTML;
alert(myeditor.body.innerHTML);
}

function Start(obj,width,height) {

	document.write("<img src=\"jseditor/images/bold.gif\" class=\"button\" name=\"btnBold\" onClick=\"doClick('bold')\">"); 
    document.write("<img src=\"jseditor/images/italic.gif\" class=\"button\" name=\"btnItalic\" onClick=\"doClick('italic')\">");
	document.write("<img src=\"jseditor/images/underline.gif\" class=\"button\" name=\"btnUnderline\" onClick=\"doClick('underline')\">");
	document.write("<img src=\"jseditor/images/link.gif\" class=\"button\" name=\"btnLink\" onClick=\"doLink()\">");
	document.write("<img src=\"jseditor/images/unlink.gif\" class=\"button\" name=\"btnUnlink\" onClick=\"doClick('unlink')\">");
	document.write("<img src=\"jseditor/images/picture.gif\" class=\"button\" name=\"btnImage\" onClick=\"doImage()\">");
	document.write("<br>");

	document.write("<iframe id=\"rte\" width=\"" + width + "\" height=\"" + height + "\" style=\"border:1px solid grey\">Enter text here</iframe>");
    document.write("<input type=\"hidden\" id=\"" + obj + "\"  name=\"" + obj + "\">");

		}



function doClick(command) {
document.getElementById("rte").contentWindow.document.execCommand(command, false, null); 
}

function doLink() {
 var mylink = prompt("Enter a URL:", "http://");
    if ((mylink != null) && (mylink != "")) {
      document.getElementById('rte').contentWindow.document.execCommand("CreateLink",false,mylink);
  }
}
 function doImage() {
 myimg = prompt('Enter Image URL:', 'http://');
 document.getElementById('rte').contentWindow.document.execCommand('InsertImage', false, myimg);
 }
 
 
function doAddTags(tag1,tag2)
{
 var textarea= document.getElementById('rte');
	// Code for IE
		if (document.selection) 
			{
				textarea.focus();
				var sel = document.selection.createRange();
				//alert(sel.text);
				sel.text = tag1 + sel.text + tag2;
			}
   else 
    {  // Code for Mozilla Firefox
		var len = textarea.value.length;
	    var start = textarea.selectionStart;
		var end = textarea.selectionEnd;
		
        var sel = textarea.value.substring(start, end);
	    //alert(sel);
		var rep = tag1 + sel + tag2;
        textarea.value =  textarea.value.substring(0,start) + rep + textarea.value.substring(end,len);
	}
}