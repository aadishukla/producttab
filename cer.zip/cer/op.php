<?php
//header("Content-type: application/vnd.ms-word");
//header("Content-Disposition: attachment;Filename=document_name.doc");
//echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=Windows-1252\">";

$to=$_POST['to'];
$sub=$_POST['sub'];
$data=$_POST['tbox']

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<style>
    .maindiv{
        height: 150px;
        margin:0% 1%;
        border: 2px solid red;
        padding-top: 0.8%;
        background: -moz-linear-gradient(top, #fefcea 0%, #f1da36 83%);
        background: -webkit-linear-gradient(top, #fefcea 0%,#f1da36 83%);
        background: linear-gradient(to bottom, #fefcea 0%,#f1da36 83%);
        filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#fefcea', endColorstr='#f1da36',GradientType=0 );
    }
    .con{
        margin: 0% 2%;
        color: #696969;
        text-decoration: none;
    }
    .mid{
        width: 20%;
        padding-bottom: 0.8%;
        padding-top: 0.8%;
        float: right;
        text-align: center;
    }
    .msg{
        
    }
    .to{
        
    }
    .sub{
        
    }
    .data{
        
    }
</style>
<body>
    <div class="maindiv">
        <div class="mid">
            <h2 class="con">Adarsh R Shukla</h2>
            <h3 class="con">Magento Devolaper</h3>
            <a href="mailto:ashukla@katalystteck.com" class="con">ashukla@katalystteck.com</a>
            <a href="tel:+917040905320" class="con">+917040905320</a><br>
            <b><p class="con">Date <?php echo date('d-m-y H:m:s');?></p></b>
        </div>
    </div>   
    <div class="msg">
        <div class="to">Dear<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $to;  ?> </div>
        <div class="sub"><b>Subject:- <?php echo $sub;?></b></div>
        <div class="data"><?php echo $data;//WYSWUG Data?></div>
    </div> 
</body>
</html>


