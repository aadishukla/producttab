<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Pleats\Style\Model\ResourceModel\Pleats;

use \Pleats\Style\Model\ResourceModel\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'pleats_style_id';

    /**
     * Load data for preview flag
     *
     * @var bool
     */
    protected $_previewFlag;

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Pleats\Style\Model\Pleats', 'Pleats\Style\Model\ResourceModel\Pleats');
        $this->_map['fields']['pleats_style_id'] = 'main_table.pleats_style_id';
       
        
    }
}
