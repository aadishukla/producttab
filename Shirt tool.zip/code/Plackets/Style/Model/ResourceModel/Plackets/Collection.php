<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Plackets\Style\Model\ResourceModel\Plackets;

use \Plackets\Style\Model\ResourceModel\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'plackets_style_id';

    /**
     * Load data for preview flag
     *
     * @var bool
     */
    protected $_previewFlag;

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Plackets\Style\Model\Plackets', 'Plackets\Style\Model\ResourceModel\Plackets');
        $this->_map['fields']['plackets_style_id'] = 'main_table.plackets_style_id';
       
        
    }
}
