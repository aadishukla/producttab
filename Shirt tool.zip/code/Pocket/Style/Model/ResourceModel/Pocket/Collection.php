<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Pocket\Style\Model\ResourceModel\Pocket;

use \Pocket\Style\Model\ResourceModel\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'pocket_style_id';

    /**
     * Load data for preview flag
     *
     * @var bool
     */
    protected $_previewFlag;

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Pocket\Style\Model\Pocket', 'Pocket\Style\Model\ResourceModel\Pocket');
        $this->_map['fields']['pocket_style_id'] = 'main_table.pocket_style_id';
       
        
    }
}
