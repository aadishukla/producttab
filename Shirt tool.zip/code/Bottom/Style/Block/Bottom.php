<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Bottom\Style\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\ObjectManagerInterface;
        
class Bottom extends Template
{
          
    protected $scopeConfig;
    protected $collectionFactory;
    protected $objectManager;
        
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Suit\Lapel\Model\ResourceModel\Lapel\CollectionFactory $collectionFactory,
        ObjectManagerInterface $objectManager
    ) {
        
        $this->scopeConfig = $context->getScopeConfig();
        $this->collectionFactory = $collectionFactory;
        $this->objectManager = $objectManager;
                
        parent::__construct($context);
    }
        
        
    public function getFrontLapel()
    {
                
            
        $collection = $this->collectionFactory->create()->addFieldToFilter('status', 1);
                
        /*
         * cehck for arguments,provided in block call
         */
        if ($ids_list = $this->getLapelBlockArguments()) {
            $collection->addFilter('bottom_style_id', ['in' => $ids_list], 'public');
        }
        
        return $collection;
    }
                
        
    public function getLapelBlockArguments()
    {
            
        $list =  $this->getLapelList();
                
        $listArray = [];
                
        if ($list != '') {
            $listArray = explode(',', $list);
        }
                
        return $listArray;
    }
        
    public function getMediaDirectoryUrl()
    {
            
        $media_dir = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface')
        ->getStore()
        ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
            
        return $media_dir;
    }
}
