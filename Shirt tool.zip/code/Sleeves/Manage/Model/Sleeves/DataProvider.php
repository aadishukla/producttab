<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/

namespace Sleeves\Manage\Model\Sleeves;

use Sleeves\Manage\Model\ResourceModel\Sleeves\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;

/**
 * Class DataProvider
 */
class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider {

    /**
     * @var \Magento\Cms\Model\ResourceModel\Block\Collection
     */
    protected $collection;

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;
    public $_storeManager;

    /**
     * @var array
     */
    protected $loadedData;

    /**
     * Constructor
     *
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $blockCollectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
            $name,
            $primaryFieldName,
            $requestFieldName,
            CollectionFactory $blockCollectionFactory, 
            DataPersistorInterface $dataPersistor, 
            \Magento\Store\Model\StoreManagerInterface $storeManager,
            array $meta = [],
            array $data = []
    ) { 
        $this->collection = $blockCollectionFactory->create();
        $this->_storeManager = $storeManager;
        $this->dataPersistor = $dataPersistor;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData() {

        $temp=[];
        $tempthread=[];
        $baseurl = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
              $items = $this->collection->getItems();

        /** @var \Magento\Cms\Model\Block $block */
        foreach ($items as $block) {
            $this->loadedData[$block->getId()] = $block->getData();
            

            $temp = $block->getData();

            if($temp['image']!=''){
                $image = [];
                $image[0]['name'] = $temp['image'];
                $image[0]['url'] = $baseurl . $temp['image'];
                $temp['image'] = $image;
                
            } 
            if($temp['texture']!=''){
                $texture = [];
                $texture[0]['name'] = $temp['texture'];
                $texture[0]['url'] = $baseurl . $temp['texture'];
                $temp['texture'] = $texture;
                
            } 
        }

        $data = $this->dataPersistor->get('sleeves_manage');
        
        if (!empty($data)) {
            $block = $this->collection->getNewEmptyItem();
            $block->setData($data);
            
            $this->loadedData[$block->getId()] = $block->getData();
            
            $this->dataPersistor->clear('sleeves_manage');
        }

        if (empty($this->loadedData)) {
            return $this->loadedData;
        } else {
            
            if ($block->getData('texture') != null) {
                $t2thread[$block->getId()] = $temp;
                return $t2thread;
            } else {
                return $this->loadedData;
            }

        }
    }
}
