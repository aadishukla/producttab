<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Sleeves\Manage\Model\ResourceModel\Sleeves;

use \Sleeves\Manage\Model\ResourceModel\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'sleeves_manage_id';

    /**
     * Load data for preview flag
     *
     * @var bool
     */
    protected $_previewFlag;

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Sleeves\Manage\Model\Sleeves', 'Sleeves\Manage\Model\ResourceModel\Sleeves');
        $this->_map['fields']['sleeves_manage_id'] = 'main_table.sleeves_manage_id';
       
        
    }
}
