<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/

namespace Suit\Lapel\Model\Lapel;

use Suit\Lapel\Model\ResourceModel\Lapel\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;

/**
 * Class DataProvider
 */
class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider {

    /**
     * @var \Magento\Cms\Model\ResourceModel\Block\Collection
     */
    protected $collection;

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;
    public $_storeManager;

    /**
     * @var array
     */
    protected $loadedData;

    /**
     * Constructor
     *
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $blockCollectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
    $name, $primaryFieldName, $requestFieldName, CollectionFactory $blockCollectionFactory, DataPersistorInterface $dataPersistor, \Magento\Store\Model\StoreManagerInterface $storeManager, array $meta = [], array $data = []
    ) {
        $this->collection = $blockCollectionFactory->create();
        $this->_storeManager = $storeManager;
        $this->dataPersistor = $dataPersistor;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData() {
        $temp=[];
        $tempthread=[];
        $baseurl = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        // var_dump($items); die;
        /** @var \Magento\Cms\Model\Block $block */
        foreach ($items as $block) {
            $this->loadedData[$block->getId()] = $block->getData();


            $temp = $block->getData();
//            echo '<pre>';var_dump($temp);die;

            if($temp['main_image']!=''){
                $main_image = [];
                $main_image[0]['name'] = $temp['main_image'];
                $main_image[0]['url'] = $baseurl . $temp['main_image'];
                $temp['main_image'] = $main_image;
            }    
           if($temp['objimage']!=''){
                $objimage = [];
                $objimage[0]['name'] = $temp['objimage'];
                $objimage[0]['url'] = $baseurl . $temp['objimage'];
                $temp['objimage'] = $objimage;
            }   
           if($temp['mlt_image']!=''){
                $mlt_image = [];
                $mlt_image[0]['name'] = $temp['mlt_image'];
                $mlt_image[0]['url'] = $baseurl . $temp['mlt_image'];
                $temp['mlt_image'] = $mlt_image;
            } 
        }

        $data = $this->dataPersistor->get('suit_lapel');

        if (!empty($data)) {
            $block = $this->collection->getNewEmptyItem();
            $block->setData($data);

            $this->loadedData[$block->getId()] = $block->getData();

            $this->dataPersistor->clear('suit_lapel');
        }

        if (empty($this->loadedData)) {
            return $this->loadedData;
        } else {
            
            if ($block->getData('mlt_image') != null) {
                $t2thread[$block->getId()] = $temp;
                return $t2thread;
            } else {
                return $this->loadedData;
            }
            
        }
    }
}
