<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Suit\Lapel\Model\ResourceModel\Lapel;

use \Suit\Lapel\Model\ResourceModel\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'suit_lapel_id';

    /**
     * Load data for preview flag
     *
     * @var bool
     */
    protected $_previewFlag;

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Suit\Lapel\Model\Lapel', 'Suit\Lapel\Model\ResourceModel\Lapel');
        $this->_map['fields']['suit_lapel_id'] = 'main_table.suit_lapel_id';
    }
}
