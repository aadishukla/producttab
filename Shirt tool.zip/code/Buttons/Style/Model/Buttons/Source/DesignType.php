<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Buttons\Style\Model\Buttons\Source;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class Status
 */
class DesignType implements OptionSourceInterface
{
    
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        
        return [
            ['value' => '1', 'label' => __('fit')],
            ['value' => '2', 'label' => __('Slim')],
            ['value' => '3', 'label' => __('Loose Fit')]
        ];
    }
}
