<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Manage\Shirt\Model\Shirt\Source;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class Status
 */
class Tiecolor implements OptionSourceInterface
{
    
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        
        return [
            ['value' => '1', 'label' => __('Red')],
            ['value' => '2', 'label' => __('Blue')],
            ['value' => '3', 'label' => __('Black')]
        ];
    }
}
