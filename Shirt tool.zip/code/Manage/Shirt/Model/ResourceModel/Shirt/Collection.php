<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Manage\Shirt\Model\ResourceModel\Shirt;

use \Manage\Shirt\Model\ResourceModel\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'manage_shirt_id';

    /**
     * Load data for preview flag
     *
     * @var bool
     */
    protected $_previewFlag;

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Manage\Shirt\Model\Shirt', 'Manage\Shirt\Model\ResourceModel\Shirt');
        $this->_map['fields']['manage_shirt_id'] = 'main_table.manage_shirt_id';
       
        
    }
}
