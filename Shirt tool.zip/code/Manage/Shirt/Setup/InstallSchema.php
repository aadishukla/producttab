<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Manage\Shirt\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class InstallSchema implements InstallSchemaInterface {

    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context) {


        $installer = $setup;
        $installer->startSetup();

        /**
         * Create table 'manage_shirt'
         */
        $table = $installer->getConnection()->newTable($installer->getTable('manage_shirt'))
            ->addColumn(
                'manage_shirt_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Lapel ID'
            )
            ->addColumn(
                'name',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['nullable' => true, 'default' => null],
                'name'
            )
            ->addColumn(
                'price',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 
                null,
                ['nullable' => true, 'default' => null],
                'price'
            )                
            ->addColumn(
                'article_number',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 
                null,
                ['nullable' => true, 'default' => null],
                'artical no'
            )   
            ->addColumn(
                'weight',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 
                null,
                ['nullable' => true, 'default' => null],
                'weight'
            )                    

            ->addColumn(
                'main_image',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                [], 
                'main image'
            )
            ->addColumn(
                'thumbnail_image',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                [], 
                'thumbnail image'
            )
            ->addColumn(
                'composition',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                [], 
                'composition'
            )
            ->addColumn(
                'tie_color',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                [], 
                'tie_color'
            )
           ->addColumn(
                'shoes_color',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                [], 
                'shoes_color'
            )
           ->addColumn(
                'material_parent',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                [], 
                'material_parent'
            )           
           ->addColumn(
                'pattern_parent',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                [], 
                'pattern_parent'
            )
           ->addColumn(
                'category_parent',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                [], 
                'category_parent'
            )    
          ->addColumn(
                'color_parent',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                [], 
                'color_parent'
            )   
          ->addColumn(
                'type',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                [], 
                'type'
            );


        $installer->getConnection()->createTable($table);
        $installer->endSetup();
    }

}
