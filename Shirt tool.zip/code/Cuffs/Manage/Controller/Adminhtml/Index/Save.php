<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Cuffs\Manage\Controller\Adminhtml\Index;

use Magento\Backend\App\Action\Context;
use Magento\Backend\App\Action;
use Cuffs\Manage\Model\Cuff;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\TestFramework\Inspection\Exception;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\RequestInterface;

//use Magento\Framework\Stdlib\DateTime\DateTime;
//use Magento\Ui\Component\MassAction\Filter;
//use FME\News\Model\ResourceModel\Test\CollectionFactory;

class Save extends \Magento\Backend\App\Action
{
    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;
    protected $scopeConfig;
   
    protected $_escaper;
    protected $inlineTranslation;
    protected $_dateFactory;
    public $fabric_id;
    //protected $_modelNewsFactory;
  //  protected $collectionFactory;
   //  protected $filter;
    /**
     * @param Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param DataPersistorInterface $dataPersistor
     */
    public function __construct(
        Context $context,
        DataPersistorInterface $dataPersistor,
        \Magento\Framework\Escaper $escaper,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Stdlib\DateTime\DateTimeFactory $dateFactory
    ) {
       // $this->filter = $filter;
       // $this->collectionFactory = $collectionFactory;
        $this->dataPersistor = $dataPersistor;
         $this->scopeConfig = $scopeConfig;
         $this->_escaper = $escaper;
        $this->_dateFactory = $dateFactory;
         $this->inlineTranslation = $inlineTranslation;
        parent::__construct($context);
        $this->fabric_id = 1;
        


        $this->objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $this->connection = $this->objectManager->get('Magento\Framework\App\ResourceConnection')->getConnection('\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION'); 
        

        $this->directory= $this->objectManager->get('\Magento\Framework\Filesystem\DirectoryList');
        $this->rootPath1  =  $this->directory->getRoot();
        $this->rootPath   = $this->rootPath1."/pub/media";    

    }

    /**
     * Save action
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return \Magento\Framework\Controller\ResultInterface
     */



    public function execute()
    {

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        
        if ($data) {
            $id = $this->getRequest()->getParam('cuffs_manage_id');

            if (isset($data['status']) && $data['status'] === 'true'){
                $data['status'] = Block::STATUS_ENABLED;
            }
            if (empty($data['cuffs_manage_id'])) {
                $data['cuffs_manage_id'] = null;
            }
           
           
            /** @var \Magento\Cms\Model\Block $model */
            $model = $this->_objectManager->create('Cuffs\Manage\Model\Cuff')->load($id);
            if (!$model->getId() && $id) {
                $this->messageManager->addError(__('This cuffs_manage no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }
            
            
            if (isset($data['image'][0]['name']) && isset($data['image'][0]['tmp_name'])) {
                $data['image'] ='/cuffs_manage/'.$data['image'][0]['name'];
            }elseif (isset($data['image'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['image'] =$data['image'][0]['name'];
            } else {
                $data['image'] = null;
            }

            if (isset($data['texture'][0]['name']) && isset($data['texture'][0]['tmp_name'])) {
                $data['texture'] ='/cuffs_manage/'.$data['texture'][0]['name'];
            }elseif (isset($data['texture'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['texture'] =$data['texture'][0]['name'];
            } else {
                $data['texture'] = null;
            }
            
            $model->setData($data);

            $this->inlineTranslation->suspend();
            try {
                
                $model->save();

                $this->messageManager->addSuccess(__('cuffs_manage Saved successfully'));
                $this->dataPersistor->clear('cuffs_manage');

                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['cuffs_manage_id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');

            } catch (LocalizedException $e) {
                    $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                echo $e; die;
                    $this->messageManager->addException($e, __('Something went wrong while saving the Data .'));
                    // print_r($e); 
            }

            $this->dataPersistor->set('cuffs_manage', $data);
            return $resultRedirect->setPath('*/*/edit', ['cuffs_manage_id' => $this->getRequest()->getParam('cuffs_manage_id')]);
            
        }
        return $resultRedirect->setPath('*/*/');
    }
}
