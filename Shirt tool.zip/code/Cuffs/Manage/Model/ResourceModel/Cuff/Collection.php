<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Cuffs\Manage\Model\ResourceModel\Cuff;

use \Cuffs\Manage\Model\ResourceModel\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'cuffs_manage_id';

    /**
     * Load data for preview flag
     *
     * @var bool
     */
    protected $_previewFlag;

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Cuffs\Manage\Model\Cuff', 'Cuffs\Manage\Model\ResourceModel\Cuff');
        $this->_map['fields']['cuffs_manage_id'] = 'main_table.cuffs_manage_id';
       
        
    }
}
