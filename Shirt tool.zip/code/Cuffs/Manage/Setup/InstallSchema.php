<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Cuffs\Manage\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class InstallSchema implements InstallSchemaInterface {

    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context) {


        $installer = $setup;
        $installer->startSetup();

        /**
         * Create table 'collar_style'
         */
        $table = $installer->getConnection()->newTable($installer->getTable('cuffs_manage'))
            ->addColumn(
                'cuffs_manage_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Cuff ID'
            )
            ->addColumn(
                'class',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null,
                ['nullable' => true, 'default' => null],
                'Class'
                )
            ->addColumn(
                'parent',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                255,
                ['nullable' => true, 'default' => null],
                'parent'
            )
            ->addColumn(
                'price',
                \Magento\Framework\DB\Ddl\Table::TYPE_FLOAT, 
                null,
                ['nullable' => true, 'default' => null],
                'price'
            )                
            ->addColumn(
                'designType',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 
                null,
                ['nullable' => true, 'default' => null],
                'designType'
            )   
            ->addColumn(
                'name',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 
                null,
                ['nullable' => true, 'default' => null],
                'name'
            )                    

            ->addColumn(
                'image',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                [], 
                'image'
            )
            ->addColumn(
                'texture',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                [], 
                'texture'
            );


        $installer->getConnection()->createTable($table);
        $installer->endSetup();
    }

}
