<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Fit\Style\Model\ResourceModel\Fit;

use \Fit\Style\Model\ResourceModel\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'fit_style_id';

    /**
     * Load data for preview flag
     *
     * @var bool
     */
    protected $_previewFlag;

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Fit\Style\Model\Fit', 'Fit\Style\Model\ResourceModel\Fit');
        $this->_map['fields']['fit_style_id'] = 'main_table.fit_style_id';
       
        
    }
}
