<?php

namespace Json\Module\Controller\Style;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;

class Index extends \Magento\Framework\App\Action\Action
{

 public function __construct( 
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        Context $context
    ) {

        $this->resultJsonFactory = $resultJsonFactory;
        parent::__construct($context);
    }
    /**
     * Execute view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    { 
        
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();

        
        
      //Collor Data
        $collar_style = $resource->getTableName('collar_style');
        $collar_style_result = $connection->fetchAll('Select * FROM '.$collar_style);
        $json_collar_style_result = array(
             "id"=> 1,
            "name"=> "Collar Style",
            "designType"=> "shirt",
            "class"=> "icon-Collar_Main_Icon",
            "img"=> "",
            "style" => $collar_style_result
            );        
      //Cuffs data
        $cuffs_manage = $resource->getTableName('cuffs_manage');
        $cuffs_manage_result = $connection->fetchAll('Select * FROM '.$cuffs_manage);
        $json_cuffs_manage_result = array(
            "id"=> 2,
            "name"=> "Cuffs",
            "designType"=> "shirt",
            "class"=> "icon-Cuff_Main_Icon",
            "img"=> "",
            "style"=>$cuffs_manage_result
            );         
       //Sleeves Data 
        $sleeves_manage = $resource->getTableName('sleeves_manage');
        $sleeves_manage_result = $connection->fetchAll('Select * FROM '.$sleeves_manage);    
        $json_sleeves_manage_result = array(
            "id"=> 3,
            "name"=> "Sleeves",
            "designType"=> "shirt",
            "class"=> "icon-Sleeve_Main_Icon",
            "img"=> "",
            "style" => $sleeves_manage_result
            );             
        //fit_style
        $fit_style = $resource->getTableName('fit_style');
        $fit_style_result = $connection->fetchAll('Select * FROM '.$fit_style);
        $json_fit_style_result = array(
            "id"=> 4,
            "name"=> "Fit",
            "designType"=> "shirt",
            "class"=> "icon-Fit_Main_Icon",
            "img"=> "",
            "style"=>  $fit_style_result
            );                     
        //buttons_style
        $buttons_style = $resource->getTableName('buttons_style');
        $buttons_style_result = $connection->fetchAll('Select * FROM '.$buttons_style);    
        $json_buttons_style_result =array(  
            "id"=> 5,
            "name"=> "Buttons",
            "designType"=> "shirt",
            "class"=> "icon-v2-buttons",
            "img"=> "buttons/Beige.png",
            "style"=> $buttons_style_result
            );
        //threads_style
        $threads_style = $resource->getTableName('threads_style');
        $threads_style_result = $connection->fetchAll('Select * FROM '.$threads_style); 
        $json_threads_style_result =array(
            "id"=> 6,
            "name"=> "Threads",
            "designType"=> "shirt",
            "class"=> "icon-v2-buttons",
            "img"=> "threads/thumb_01.png",
            "style"=> $threads_style_result

            );           
        //pocket_style
        $pocket_style = $resource->getTableName('pocket_style');
        $pocket_style_result = $connection->fetchAll('Select * FROM '.$pocket_style);   
        $json_pocket_style_result  =array(
            "id"=> 7,
            "name"=> "Pocket",
            "designType"=> "shirt",
            "class"=> "icon-Withoutflap_Pocket_Right",
            "img"=> "",
            "style"=> $pocket_style_result
            );    
        //plackets_style
        $plackets_style = $resource->getTableName('plackets_style');
        $plackets_style_result = $connection->fetchAll('Select * FROM '.$plackets_style);    
        $json_plackets_style_result = array(
            "id"=> 8,
            "name"=> "Plackets",
            "designType"=> "shirt",
            "class"=> "icon-Placket_Main_Icon",
            "img"=> "",
            "style"=> $plackets_style_result
            );     
        //pleats_style
        $pleats_style = $resource->getTableName('pleats_style');
        $pleats_style_result = $connection->fetchAll('Select * FROM '.$pleats_style);  
        $json_pleats_style_result = array(
            "id"=> 9,
            "name"=> "Pleats",
            "designType"=> "shirt",
            "class"=> "icon-Pleats_Main_Icon",
            "img"=> "",
            "style"=> $pleats_style_result
            );      
        //bottom_style
        $bottom_style = $resource->getTableName('bottom_style');
        $bottom_style_result = $connection->fetchAll('Select * FROM '.$bottom_style);   
        $json_bottom_style_result = array(
            "id"=> 10,
            "name"=> "Bottom",
            "designType"=> "shirt",
            "class"=> "icon-Bottom_Main_Icon",
            "img"=> "",
            "style"=> $bottom_style_result           
            );      
        
        
        


        //Combine all Data in array
        $arr=array(
            "Collors" =>$json_collar_style_result,
            "Cuffs"   =>$json_cuffs_manage_result,
            "Sleeves" =>$json_sleeves_manage_result,
            "Fit"     =>$json_fit_style_result,
            "Buttons" =>$json_buttons_style_result,
            "Threads" =>$json_threads_style_result,
            "Pockets" =>$json_pocket_style_result,
            "Plackets"=>$json_plackets_style_result,
            "pleats"  =>$json_pleats_style_result,
            "Bottom"  =>$json_bottom_style_result
            );

        
        //returnig json
        $data = $this->resultJsonFactory->create();
        return $data->setData($arr);
    }



}
