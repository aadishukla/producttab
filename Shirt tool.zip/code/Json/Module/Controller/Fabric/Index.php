<?php

namespace Json\Module\Controller\Fabric;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Json\Module\Model\JsonFactory;

class Index extends \Magento\Framework\App\Action\Action
{

 protected $_manageshirt;
 protected $_Addfabric;

 public function __construct( 
        \Json\Module\Model\MangeshirtJsonFactory $manage_shirt,
        \Json\Module\Model\AddfabricJsonFactory $add_fabric,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        Context $context
    ) {
        $this->_manageshirt = $manage_shirt;
        $this->_Addfabric = $add_fabric;
        $this->resultJsonFactory = $resultJsonFactory;
        parent::__construct($context);
    }
    /**
     * Execute view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    { 

        $manageshirtresult = $this->_manageshirt->create();
        $manageshirtdata = $manageshirtresult->getCollection();


        $addfabricresult = $this->_Addfabric->create();
        $addfabricdata = $addfabricresult->getCollection(); 
        
        
        $result=array('fabric'=>$manageshirtdata->getData());
        $data = $this->resultJsonFactory->create();
        return $data->setData($result);
    }
}
