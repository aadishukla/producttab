<?php


namespace Json\Module\Model;
	 
use Magento\Framework\Model\AbstractModel;
	 
	class AddfabricJson extends AbstractModel
	{	
	    protected function _construct()
	    {
                $this->_init('Json\Module\Model\ResourceModel\AddfabricJson');
	    }
	}