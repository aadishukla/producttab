<?php


namespace Json\Module\Model;
	 
use Magento\Framework\Model\AbstractModel;
	 
	class MangeshirtJson extends AbstractModel
	{	
	    protected function _construct()
	    {
	        $this->_init('Json\Module\Model\ResourceModel\ManageshirtJson');
	    }
	}