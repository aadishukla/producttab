<?php


namespace Json\Module\Model\ResourceModel\ManageshirtJson;


use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;


class Collection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init(
	    'Json\Module\Model\MangeshirtJson',
	    'Json\Module\Model\ResourceModel\ManageshirtJson'
		);
    }
}