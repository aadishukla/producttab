<?php
	 
namespace Json\Module\Model\ResourceModel;


use \Magento\Framework\Model\ResourceModel\Db\AbstractDb;
	 
class ManageshirtJson extends AbstractDb
{
    protected function _construct()
    {
        $this->_init('manage_shirt', 'manage_shirt_id');
    }
}
