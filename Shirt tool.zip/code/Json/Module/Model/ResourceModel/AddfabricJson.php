<?php
	 
namespace Json\Module\Model\ResourceModel;


use \Magento\Framework\Model\ResourceModel\Db\AbstractDb;
	 
class AddfabricJson extends AbstractDb
{
    protected function _construct()
    {
        $this->_init('suit_lapel', 'suit_lapel_id');
    }
}