<?php
namespace  Json\Module\Block;
 
class Tool extends \Magento\Framework\View\Element\Template
{
    public function ToolFunction()
    {
        return 'Hello world!';
    }
}