<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Collar\Style\Model\Collar\Source;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class Category_parent
 */
class getParent implements OptionSourceInterface
{
    
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        
        return [
            ['value' => '1', 'label' => __('Notch')],
            ['value' => '2', 'label' => __('Peak')],
            ['value' => '3', 'label' => __('Shawl')]
        ];
    }
}
