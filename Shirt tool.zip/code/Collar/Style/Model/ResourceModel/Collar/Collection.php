<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Collar\Style\Model\ResourceModel\Collar;

use \Collar\Style\Model\ResourceModel\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'manage_collar_id';

    /**
     * Load data for preview flag
     *
     * @var bool
     */
    protected $_previewFlag;

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Collar\Style\Model\Collar', 'Collar\Style\Model\ResourceModel\Collar');
        $this->_map['fields']['manage_collar_id'] = 'main_table.manage_collar_id';
       
        
    }
}
