<?php
  
namespace Akshay\Tab\Setup;
  
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
  
class InstallSchema implements InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
  
        // Get emipro_sampletable table
        $tableName = $installer->getTable('custom_tab');
        // Check if the table already exists
        if ($installer->getConnection()->isTableExists($tableName) != true) {
            // Create emipro_sampletable table
            $table = $installer->getConnection()
                ->newTable($tableName)
                
                ->addColumn(
                    'pkey',
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'unsigned' => true,
                        'nullable' => false,
                        'primary' => true
                    ],
                    'ID'
                    )
                    
                ->addColumn(
                    'id',
                    Table::TYPE_INTEGER,
                    null,
                    [ ],
                    'ID'
                )
                ->addColumn(
                    'tab_value',
                    Table::TYPE_TEXT,
                    200,
                    ['nullable' => false, 'default' => ''],
                    'Tab From Block'
                    )
                    
                 ->addIndex( // to make product_id unique
                        $installer->getIdxName(
                            'custom_tab',
                            ['id'],
                            \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE
                            ),
                        'id',
                        ['type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE]
                        )->setComment(
                            'Connector Channels'
                            );
            
                
            $installer->getConnection()->createTable($table);
        }
  
        $installer->endSetup();
    }
}